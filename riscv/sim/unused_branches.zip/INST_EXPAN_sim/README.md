指令 li $t1,40 是一条伪指令，在汇编器中会转换成 addi $t1,$zero,40. 

Passed test: 
1. _out_abc.c: lui, jal, sb, addi, 
2. _funct.c: lw, andi, beqz, srli, bne, jalr, sw, 


如果我不改变hci的时钟，只改变参数的话，assertion会失败。
hci在仿真的时候，似乎不会进入disable的状态，也就是说cpu永远不会工作。